package com.edix.proyecto_examen_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoExamenFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
