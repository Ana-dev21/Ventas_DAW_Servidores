package com.edix.ventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoExamenFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoExamenFinalApplication.class, args);
	}

}
